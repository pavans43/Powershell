
param (
  $ServerName,
  $JenkinsJobName,
  $ConsoleAppFolderName,
  $ConsoleAppFolderPath 
)

<#
To call this script from Jenkins create a new "Execute Windows Batch Command" and enter the following:
Note: change any server names and directories etc to suit as this is only an example.

NOTE: 	
    This was created from the original script by removing all IIS references.
	The script will have to be included in the original script deploy_remote_server 
    so that we have just one script to deploy all console apps and web apps.


powershell ^
  -File %script_path%\deploy_remote_server.ps1 ^
  -ServerName "espw-t-001.healthshare.local" ^
  -JenkinsJobName "User Directory Import Utility - HT Release" ^
  -ConsoleAppFolderName "UserDirectoryImportUtility" ^
  -ConsoleAppFolderPath "C:\Midland\ConsoleApps\\"

#>


function CopyToDeploymentServer {
    param (
        [string] $ServerName,
        [string] $JenkinsJobName,
        [string] $ConsoleAppFolderName,
        [string] $ConsoleAppFolderPath
    )
    # This command is used to exit out of the script on encountering any error so that the rest of the script
    # is not executed.
    $ErrorActionPreference = "Stop"

    Write-Host -ForegroundColor Green "`r`n"
    Write-Host -ForegroundColor Green "Printing all the parameters passed."
    Write-Host -ForegroundColor Green "Deployment Server Name: $ServerName"
    Write-Host -ForegroundColor Green "Jenkins Build Job Name: $JenkinsJobName"
    Write-Host -ForegroundColor Green "Console Application Folder Name:$ConsoleAppFolderName"
    Write-Host -ForegroundColor Green "Root path of Console Application folder:$ConsoleAppFolderPath"
    Write-Host -ForegroundColor Green "`r`n"

    $passwordFromTextFile = Get-Content "D:\jenkins\scripts\password.txt"
    $jenkinsPassword = ConvertTo-SecureString $passwordFromTextFile -AsPlainText -Force
    $userCredential = New-Object -TypeName System.Management.Automation.PSCredential "SVC_MCP_JENKINS", $jenkinsPassword
    
    #####################################################################################################################
    Write-Host -ForegroundColor Green "`r`n"
    Write-Host -ForegroundColor Green "Copy Release Artifact to folder D:\Deploy on the deployment target."
   
    $ZipFileName = Get-ChildItem -Path "D:\jenkins_home\workspace\$JenkinsJobName" -Include "*$JenkinsJobName*.zip" -Name
    Write-Host -ForegroundColor Green "Release Artifact to be copied to $serverName : $ZipFileName"

    $ZipFileSource = "D:\jenkins_home\workspace\$JenkinsJobName\$ZipFileName"
    $DeployDestinationRootFolder = "D:\Deploy\"

    #####################################################################################################################
    Write-Host -ForegroundColor Green "`r`n"
    Write-Host -ForegroundColor Green "Establish a session with the deployment server"
    # PSSession with the deployment server
    $sess = New-PSSession -Credential $userCredential -ComputerName $ServerName

    #####################################################################################################################
    Write-Host -ForegroundColor Green "`r`n"
    # Copy file from source to dest.
    Write-Host -ForegroundColor Green "Release Artifact Source: $ZipFileSource"
    Write-Host -ForegroundColor Green "Release Artifact Destination: $DeployDestinationRootFolder"    
    Copy-Item -Path $ZipFileSource -Destination "$DeployDestinationRootFolder" -ToSession $sess

    #####################################################################################################################
    Write-Host -ForegroundColor Green "`r`n"
    $DeploymentFolder = "$DeployDestinationRootFolder" + $JenkinsJobName
    Write-Host -ForegroundColor Green "Creating Directory $DeploymentFolder on target env. Unzip the zip file"

    Write-Host -ForegroundColor Green "Pre-deploy cleanup. Delete unzipped folders from $DeploymentFolder if exists."
    if (Invoke-Command -Session $sess -ScriptBlock {Test-Path $using:DeploymentFolder}){
        Invoke-Command -Session $sess -ScriptBlock {Remove-Item $using:DeploymentFolder -Recurse -Force}
    }

    # Create a folder to unpack the contents of the zip file.
    Invoke-Command -Session $sess -ScriptBlock {New-Item -ItemType Directory -Force -Path $using:DeploymentFolder}
    
    Write-Host -ForegroundColor Green "Directory created: $DeploymentFolder"

    # Unzip. What else
    Invoke-Command -Session $sess -ScriptBlock {Expand-Archive -Path "$using:DeployDestinationRootFolder\$using:ZipFileName" -DestinationPath $using:DeploymentFolder}

    Write-Host -ForegroundColor Green "Zip file contents unzipped to deployment folder."

    #####################################################################################################################
    Write-Host -ForegroundColor Green "Rename existing Console App folder"
    $AppBackupFolderName = $ConsoleAppFolderName+"_backup_"+(Get-Date -Format "yyyy-MM-dd_HHmm")
    
    Write-Host -ForegroundColor Green "Backup Folder Name: $AppBackupFolderName"

    $ConsoleAppLocation = $ConsoleAppFolderPath + $ConsoleAppFolderName
    
    # Rename the Console Application folder so that we have a backup.
    Invoke-Command -Session $sess -ScriptBlock {Rename-Item -Path $using:ConsoleAppLocation -NewName $using:AppBackupFolderName}    
    
    #####################################################################################################################
    Write-Host -ForegroundColor Green "Copying files from $DeploymentFolder to $ConsoleAppLocation"
        
    $AppBackupLocation = $ConsoleAppFolderPath + $AppBackupFolderName
    
    Write-Host -ForegroundColor Green "Create a new Console Application folder as the previous one has been renamed to _backup"

    Invoke-Command -Session $sess -ScriptBlock {New-Item -ItemType Directory -Force -Path "$using:ConsoleAppLocation"}
    
    Write-Host -ForegroundColor Green "Copy contents from the deployment folder to the Console Application Folder"
    Invoke-Command -Session $sess -ScriptBlock {Copy-Item -Path "$using:DeploymentFolder\*" -Recurse -Force -Destination $using:ConsoleAppLocation -Container}
    
    $ConsoleAppLocationDirectoryInfo = Invoke-Command -Session $sess -ScriptBlock {Get-ChildItem "$using:ConsoleAppLocation" | Measure-Object}
    if($ConsoleAppLocationDirectoryInfo.count -ne 0)
    {
      Write-Host -ForegroundColor Green "Copy ONLY the web.config and json files from the backup folder so that we retain the configuration with the new dlls"
      # Important: we need to be specific about what we overwrite because we don't want to accidentally overwrite the wrong files.
      Invoke-Command -Session $sess -ScriptBlock {Copy-Item -Path "$using:AppBackupLocation\*" -Include @("appsetting*.json", "web.config") -Recurse -Force -Destination $using:ConsoleAppLocation -Container}
    }  
   
    Write-Host -ForegroundColor Green "`r`n"
    
    # Delete unzipped folders from D:/Deploy
    Write-Host -ForegroundColor Green "`r`n"
    Write-Host -ForegroundColor Green "Delete unzipped folders from $DeploymentFolder if it exists."
    if (Invoke-Command -Session $sess -ScriptBlock {Test-Path $using:DeploymentFolder}){
        Invoke-Command -Session $sess -ScriptBlock {Remove-Item $using:DeploymentFolder -Recurse -Force}
    }

    if($ConsoleAppLocationDirectoryInfo.count -ne 0)
    {
      # Move all backup folders from C:\ConsoleApps to D:\DeploymentBackups
      Write-Host -ForegroundColor Green "Move backup folder $AppBackupLocation to D:\DeploymentBackups"
      Invoke-Command -Session $sess -ScriptBlock {Move-Item -Path "$using:AppBackupLocation" -Force -Destination "D:\DeploymentBackups\\"}
    }

    Write-Host -ForegroundColor Green "Close the remote Session"
    Remove-PSSession $sess

}
 
CopyToDeploymentServer `
    -ServerName $ServerName `
    -JenkinsJobName $JenkinsJobName `
    -ConsoleAppFolderName $ConsoleAppFolderName `
    -ConsoleAppFolderPath $ConsoleAppFolderPath

<#
CopyToDeploymentServer `
    -ServerName "cputil-d-001.healthshare.local" `
    -JenkinsJobName "User Directory Import Utility - Current Release" `
    -ConsoleAppFolderName "UserDirectoryImportUtility1" `
    -ConsoleAppFolderPath "C:\Midland\Console Apps\\" 
#>
