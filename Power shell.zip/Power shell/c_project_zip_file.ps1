param (
  $projectDLLFileName,
  $publishFolder,
  $zipDeployFolderName # e.g. dev This will be used with the deployment folder e.g. D:\jenkins\HealthShareDeploymentPackages\dev
)

$ErrorActionPreference = "Stop"

# Couldn't get param validation to work so manually validating.
if(!$projectDLLFileName)
{
  Write-Error "The param 'projectDLLFileName' cannot be empty. Please provide the name of the project dll file."
  exit 1
}

if(!$publishFolder)
{
  Write-Error "The param 'publishFolder' cannot be empty. Please provide the path to the publish output directory."
  exit 1
}

# Search all directories until the dll is found and find the version of the dll.
$productVersion = (Get-ChildItem -Path "$publishFolder\" -Include "$projectDLLFileName" -Recurse).VersionInfo.ProductVersion
Write-Host $productVersion 

$zipFileName = "$($productVersion)_$env:BUILD_TAG.zip"

Compress-Archive -Path "$publishFolder/*" -DestinationPath "$zipFileName" -Force

Write-Host "Zip file $zipFileName created."

# We don't want to copy the zip files for the development builds.
if($zipDeployFolderName)
{
  $fullDeploymentFolder = "$env:healthshare_deployment_path\$zipDeployFolderName"

  New-Item -ItemType Directory -Force -Path $fullDeploymentFolder

  Write-Host "Copying Zip file $zipFileName to $fullDeploymentFolder"

  Copy-Item $env:workspace\$zipFileName -Destination $fullDeploymentFolder

  Write-Host "Successfully copied Zip file $zipFileName to $fullDeploymentFolder"
}



