
$Username = "SVC_MCP_JENKINS"
$Password = "lrA$B^Y*4,k3VahG'LOO"

$BinariesToBeDeployed = "jenkins-Auth Server - HT Release-8.zip"
$DeploymentTarget = "espw-t-001.healthshare.localy"
$DeploymentAppPool = "DefaultAppPool"

$SevenZip = "C:\Program Files\7-Zip\7z.exe"
$DirToZip = "\\"+$DeploymentTarget+"\c$\inetpub\wwwroot"
$ZipFileName = "$DirToZip-$(Get-Date -f yyyyMMdd-HHmmss)"

# $Cred = New-Object System.Management.Automation.PSCredential ($Username, $Password)
Enter-PSSession -ComputerName $DeploymentTarget -Credential $Cred
Invoke-Command -ComputerName $DeploymentTarget -ScriptBlock { Import-Module WebAdministration; Stop-WebAppPool -Name $DeploymentAppPool }

# Point to the 
&$SevenZip a $ZipFileName $DirToZip

$Source = "D:\jenkins\HealthShareDeploymentPackages\"+$BinariesToBeDeployed
$Dest = $DirToZip+"\"+$BinariesToBeDeployed

$WebClient = New-Object System.Net.WebClient
$WebClient.Credentials = New-Object System.Net.NetworkCredential($Username, $Password)

$WebClient.DownloadFile($Source, $Dest)

# Unzip
# Change credentials
# Invoke-Command -ComputerName $DeploymentTarget -ScriptBlock { Start-WebAppPool -Name $DeploymentAppPool }
