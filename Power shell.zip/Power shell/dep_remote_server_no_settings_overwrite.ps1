
param (
  $ServerName,
  $JenkinsJobName,
  $IISApplicationFolderName,
  $IISApplicationFolderPath,  
  $IISApplicationPoolName  
)

<#
To call this script from Jenkins create a new "Execute Windows Batch Command" and enter the following:
Note: change any server names and directories etc to suit as this is only an example.


powershell ^
  -File %script_path%\deploy_remote_server.ps1 ^
  -ServerName "espw-t-001.healthshare.local" ^
  -JenkinsJobName "User Directory API - HT Release" ^
  -IISApplicationFolderName "UserDirectory" ^
  -IISApplicationFolderPath "C:\inetpub\wwwroot\" ^
  -IISApplicationPoolName "DefaultAppPool"

#>


function CopyToDeploymentServer {
    param (
        [string] $ServerName,
        [string] $JenkinsJobName,
        [string] $IISApplicationFolderName,
        [string] $IISApplicationFolderPath,
        [string] $IISApplicationPoolName
    )
    # This command is used to exit out of the script on encountering any error so that the rest of the script
    # is not executed.
    $ErrorActionPreference = "Stop"

    Write-Host -ForegroundColor Green "`r`n"
    Write-Host -ForegroundColor Green "Printing all the parameters passed."
    Write-Host -ForegroundColor Green "Deployment Server Name: $ServerName"
    Write-Host -ForegroundColor Green "Jenkins Build Job Name: $JenkinsJobName"
    Write-Host -ForegroundColor Green "IIS Application Folder Name:$IISApplicationFolderName"
    Write-Host -ForegroundColor Green "Root path of IIS Application folder:$IISApplicationFolderPath"
    Write-Host -ForegroundColor Green "Application Pool Name in IIS: $IISApplicationPoolName"
    Write-Host -ForegroundColor Green "`r`n"

    Write-Host -ForegroundColor Green "Creating deploy credentials."
    $jenkinsPassword = ConvertTo-SecureString $env:deploy_password -AsPlainText -Force
    $userCredential = New-Object -TypeName System.Management.Automation.PSCredential "$env:deploy_username", $jenkinsPassword

    Write-Host -ForegroundColor Green "Getting application pool from IIS..."
    $appPool = Get-AppPool -IISApplicationPoolName $IISApplicationPoolName -ServerName $ServerName -UserCredentials $userCredential
    
    Write-Host -ForegroundColor Green "Stopping application pool..."
    Stop-AppPool -serverName $serverName  -AppPool $appPool -IISApplicationPoolName $IISApplicationPoolName
        
    ######### Creating the Zip File with the tokens replaced.
    $SourceFolderName = Get-ChildItem -Path . -Include "*$JenkinsJobName*" -Name   
    Write-Host -ForegroundColor Green "Creating Zip file from source folder: $SourceFolderName ..."  
    Compress-Archive -Path "$SourceFolderName/*" -DestinationPath "$SourceFolderName.zip" -Force

    #####################################################################################################################
    Write-Host -ForegroundColor Green "`r`n"
    Write-Host -ForegroundColor Green "Copy Release Artifact to folder D:\Deploy on the deployment target."
   
    $ZipFileSource = "$SourceFolderName.zip"
    Write-Host -ForegroundColor Green "Release Artifact to be copied to $serverName : $ZipFileSource"

    $DeployDestinationRootFolder = "D:\Deploy\"

    #####################################################################################################################
    Write-Host -ForegroundColor Green "`r`n"
    Write-Host -ForegroundColor Green "Establish a session with the deployment server"
    # PSSession with the deployment server
    $sess = New-PSSession -Credential $userCredential -ComputerName $ServerName

    #####################################################################################################################
    Write-Host -ForegroundColor Green "`r`n"
    # Copy file from source to dest.
    Write-Host -ForegroundColor Green "Release Artifact Source: $ZipFileSource"
    Write-Host -ForegroundColor Green "Release Artifact Destinatiion: $DeployDestinationRootFolder"    
    Copy-Item -Path $ZipFileSource -Destination "$DeployDestinationRootFolder" -ToSession $sess

    #####################################################################################################################
    Write-Host -ForegroundColor Green "`r`n"
    $DeploymentFolder = "$DeployDestinationRootFolder" + $JenkinsJobName
    Write-Host -ForegroundColor Green "Creating Directory $DeploymentFolder on target env. Unzip the zip file"

    Write-Host -ForegroundColor Green "Pre-deploy cleanup. Delete unzipped folders from $DeploymentFolder if exists."
    if (Invoke-Command -Session $sess -ScriptBlock {Test-Path $using:DeploymentFolder}){
        Invoke-Command -Session $sess -ScriptBlock {Remove-Item $using:DeploymentFolder -Recurse -Force}
    }

    # Create a folder to unpack the contents of the zip file.
    Invoke-Command -Session $sess -ScriptBlock {New-Item -ItemType Directory -Force -Path $using:DeploymentFolder}
    
    Write-Host -ForegroundColor Green "Directory created: $DeploymentFolder"

    # Unzip. What else
    Invoke-Command -Session $sess -ScriptBlock {Expand-Archive -Path "$using:DeployDestinationRootFolder\$using:ZipFileSource" -DestinationPath $using:DeploymentFolder}

    Write-Host -ForegroundColor Green "Zip file contents unzipped to deployment folder."

    #####################################################################################################################
    Write-Host -ForegroundColor Green "Rename existing WebApp folder"
    $IISBackupFolderName = $IISApplicationFolderName+"_backup_"+(Get-Date -Format "yyyy-MM-dd_HHmm")
    
    Write-Host -ForegroundColor Green "Backup Folder Name: $IISBackupFolderName"

    $IISApplicationLocation = $IISApplicationFolderPath + $IISApplicationFolderName
    
    # Rename the IIS Application folder so that we have a backup.
    Invoke-Command -Session $sess -ScriptBlock {Rename-Item -Path $using:IISApplicationLocation -NewName $using:IISBackupFolderName}    
    
    #####################################################################################################################
    Write-Host -ForegroundColor Green "Copying files from $DeploymentFolder to $IISApplicationLocation"
        
    $IISBackupLocation = $IISApplicationFolderPath + $IISBackupFolderName
    
    Write-Host -ForegroundColor Green "Create a new IIS Application folder as the previous one has been renamed to _backup"

    Invoke-Command -Session $sess -ScriptBlock {New-Item -ItemType Directory -Force -Path "$using:IISApplicationLocation"}
    
    Write-Host -ForegroundColor Green "Copy contents from the deployment folder to the IIS Application Folder"
    Invoke-Command -Session $sess -ScriptBlock {Copy-Item -Path "$using:DeploymentFolder\*" -Recurse -Force -Destination $using:IISApplicationLocation -Container}
           
    Write-Host -ForegroundColor Green "`r`n"
    Start-AppPool -ServerName $ServerName  -AppPool $appPool -IISApplicationPoolName $IISApplicationPoolName
    
    # Delete unzipped folders from D:/Deploy
    Write-Host -ForegroundColor Green "`r`n"
    Write-Host -ForegroundColor Green "Delete unzipped folders from $DeploymentFolder if it exists."
    if (Invoke-Command -Session $sess -ScriptBlock {Test-Path $using:DeploymentFolder}){
        Invoke-Command -Session $sess -ScriptBlock {Remove-Item $using:DeploymentFolder -Recurse -Force}
    }

    $iisAppLocationDirectoryInfo = Invoke-Command -Session $sess -ScriptBlock {Get-ChildItem "$using:IISApplicationLocation" | Measure-Object}
    if($iisAppLocationDirectoryInfo.count -ne 0)
    {
      # Move all backup folders from C:\WebApps to D:\DeploymentBackups
      Write-Host -ForegroundColor Green "Move backup folder $IISBackupLocation to D:\DeploymentBackups"
      Invoke-Command -Session $sess -ScriptBlock {Move-Item -Path "$using:IISBackupLocation" -Force -Destination "D:\DeploymentBackups\\"}
    }

    Write-Host -ForegroundColor Green "Close the remote Session"
    Remove-PSSession $sess

    # Remove the source zip file from the current Jenkins deploy workspace because for multi node setups this deploy script 
    # is run multiple times and it will fail if the zip file still exists.
    Write-Host -ForegroundColor Green "Removing the source zip file from this Jenkins job workspace. Zip name: $ZipFileSource"
    Remove-Item $ZipFileSource -Force
}
 
function ConvertAppPoolState {
    param(
        [int] $value
    )
    switch($value)
    {
        0 { "Starting"; break }
        1 { "Started"; break }
        2 { "Stopping"; break }
        3 { "Stopped"; break }
        default { "Unknown"; break }
    }
}

function Get-AppPool
{
    param (
        [string] $IISApplicationPoolName,
        [string] $ServerName,
        [object] $UserCredentials
    )    
    
    # Return an app pool object
    $appPool = Get-WmiObject -Authentication PacketPrivacy -Impersonation Impersonate -ComputerName `
        $ServerName -Namespace "root\WebAdministration" -Credential $userCredential -Class "ApplicationPool" `
            | Where-Object { $_.Name -eq "$IISApplicationPoolName" }
 
    # Check to make sure we actually have an object
    if ($appPool -ne $null)
    {
      return $appPool
    }
    else
    {
        Write-Host -ForegroundColor Red "Error occurred while attempting to recycle Application Pool: $IISApplicationPoolName on Server: $ServerName."
        exit 1
    }
}

function Stop-AppPool
{
    param (
        [string] $ServerName,
        [object] $AppPool,
        [string] $IISApplicationPoolName
    )

    if ((ConvertAppPoolState ($AppPool.GetState() | Select-Object -ExpandProperty ReturnValue)) -eq "Started")
    {
        Write-Host -ForegroundColor Green "Attempting to Stop Application Pool: $IISApplicationPoolName on Server: $ServerName ..."
        $AppPool.Stop()
 
        $stopAttempts = 0
        while (((ConvertAppPoolState ($AppPool.GetState() | Select-Object -ExpandProperty ReturnValue)) -eq "Stopping"))
        {
            Write-Host -ForegroundColor Yellow "Stopping..."
            $stopAttempts++
            Start-Sleep 5
 
            if ($stopAttempts -eq 10)
            {
                Write-Host -ForegroundColor Red "There was an issue with stopping the Application Pool $IISApplicationPoolName."
                exit 1
            }
        }
 
        if ((ConvertAppPoolState ($AppPool.GetState() | Select-Object -ExpandProperty ReturnValue)) -eq "Stopped")
        {
            Write-Host -ForegroundColor Green "Application Pool: $IISApplicationPoolName on Server: $ServerName stopped."
                
        }
    }
}

function Start-AppPool
{
    param (
        [string] $ServerName,        
        [object] $AppPool,
        [string] $IISApplicationPoolName
    )

    if ((ConvertAppPoolState ($AppPool.GetState() | Select-Object -ExpandProperty ReturnValue)) -eq "Stopped")
    {
        Write-Host -ForegroundColor Green "Attempting to Start Application Pool: $IISApplicationPoolName on Server: $ServerName ...."
        $AppPool.Start()
 
        if ((ConvertAppPoolState ($AppPool.GetState() | Select-Object -ExpandProperty ReturnValue)) -eq "Started")
        {
            Write-Host -ForegroundColor Green "Application Pool: $IISApplicationPoolName on Server: $ServerName started."
        }
    }    
}


CopyToDeploymentServer `
    -ServerName $ServerName `
    -JenkinsJobName $JenkinsJobName `
    -IISApplicationFolderName $IISApplicationFolderName `
    -IISApplicationFolderPath $IISApplicationFolderPath `
    -IISApplicationPoolName $IISApplicationPoolName

<#
CopyToDeploymentServer `
    -ServerName "riam-d-001.healthshare.local" `
    -JenkinsJobName "Document Retrieval API - DEV BUILD" `
    -IISApplicationFolderName "DocumentRetrievalApi" `
    -IISApplicationFolderPath "C:\Web Apps\" `
    -IISApplicationPoolName "DocumentRetrievalApi"
#>
