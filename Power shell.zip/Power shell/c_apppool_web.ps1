param{
 $IISAppPoolName,
 $IISAppPoolDotNetVersion,
 $IISWebsiteName,
 $IISDirectoryPath
}

function CreateAppPoolAndWebsite {
    Import-Module WebAdministration
    New-Item -ItemType Directory -Path $directoryPath

    #navigate to the app pools root
    cd IIS:\AppPools\

    #check if the app pool exists
    if (!(Test-Path $iisAppPoolName -pathType container))
    {
        #create the app pool
        $appPool = New-Item $iisAppPoolName
        $appPool | Set-ItemProperty -Name "managedRuntimeVersion" -Value $iisAppPoolDotNetVersion
    }

    #navigate to the sites root
    cd IIS:\Sites\

    #check if the site exists
    if (Test-Path $iisAppName -pathType container)
    {
        return
    }

    #create the site
    $iisApp = New-Item $iisAppName -bindings @{protocol="http";bindingInformation=":80:" + $iisAppName} -physicalPath $directoryPath
    $iisApp | Set-ItemProperty -Name "applicationPool" -Value $iisAppPoolName
}


<#
CopyToDeploymentServer `
    -IISAppPoolName $IISAppPoolName `
    -IISAppPoolDotNetVersion $IISAppPoolDotNetVersion `
    -IISAppName $IISAppName `
    -IISDirectoryPath $IISDirectoryPath 
#>

CopyToDeploymentServer `
    -$IISAppPoolName "my-test-app" `
    -$IISAppPoolDotNetVersion "v4.0" `
    -$IISWebsiteName "my-test-app.test" `
    -$IISDirectoryPath "D:\SomeFolder"

